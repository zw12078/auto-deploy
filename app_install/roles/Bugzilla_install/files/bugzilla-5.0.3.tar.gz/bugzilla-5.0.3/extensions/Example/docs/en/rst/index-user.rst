Example
#######

This is a sample User documentation file for the Example extension.
Like all of the Bugzilla docs, it's written in
`reStructured Text (reST) format <http://sphinx-doc.org/latest/rest.html>`_
and will be compiled by `Sphinx <http://sphinx-doc.org/>`_.

If you build the docs yourself using :file:`makedocs.pl`, this file will get
incorporated into the User Guide. If you need more than one file's worth of
user documentation, include others using the Sphinx `toctree directive <http://sphinx-doc.org/markup/toctree.html>`_.
