.. _apis:

WebService API Reference
========================

This Bugzilla installation has the following WebService APIs available
(as of the last time you compiled the documentation). Documentation for
the deprecated :ref:`XML-RPC and JSON-RPC APIs <api-list>` is also available.

.. toctree::
   :glob:

   core/v*/index
   ../extensions/*/api/v*/index
